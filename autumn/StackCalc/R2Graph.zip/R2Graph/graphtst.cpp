#include <cmath>
#include <iostream>
#include "R2Graph.h"

using namespace std;

int main() {
    cout << "Test of R2Graph package\n";
    R2Vector u, v;
    R2Point p0, p1, q0, q1;
    R2Point intersection;
    while (true) {
        cout << "Input 2 vectors:\n";
        cin >> u.x >> u.y >> v.x >> v.y;
        if (u == R2Vector(0., 0.) || v == R2Vector(0., 0.))
            break;
        double a = u.angle(v);
        cout << "angle from first to secong = " << a
            << " (" << (int) (floor(a*180./3.14158) + 0.5) 
            << " degrees)" << endl;

        cout << "Input 2 line segments:\n";
        cin >> p0.x >> p0.y >> p1.x >> p1.y;
        if (p0 == p1)
            break;
        cin >> q0.x >> q0.y >> q1.x >> q1.y;
        if (q0 == q1)
            break;
        if (intersectLineSegments(p0, p1, q0, q1, intersection)) {
            cout << "Intersection: (" <<
                intersection.x << ", " << intersection.y << ")\n";
        } else {
            cout << "Line segments do not intersect.\n";
        }

        cout << "Input 2 circles (center, radius for each):\n";
        R2Point center1, center2;
        double radius1, radius2;
        if (!(cin >> center1 >> radius1))
            break;
        if (!(cin >> center2 >> radius2))
            break;
        R2Point intersections[2];
        if (intersectCircles(
            center1, radius1,
            center2, radius2, 
            intersections
        )) {
            cout << "Points of intersection: "
                 << intersections[0] << ", "
                 << intersections[1] << endl;
        } else {
            cout << "Circles do not intersect.\n";
        }

        cout << "Input a circle (center, radius):\n";
        if (!(cin >> center1 >> radius1))
            break;
        cout << "Input a straight line (point, direction vector):\n";
        if (!(cin >> p0 >> v))
            break;
        if (intersectLineAndCircle(
            p0, v,
            center1, radius1,
            intersections
        )) {
            cout << "Points of intersection: "
                 << intersections[0] << ", "
                 << intersections[1] << endl;
        } else {
            cout << "Line and Circle do not intersect.\n";
        }
    }
    return 0;
}
